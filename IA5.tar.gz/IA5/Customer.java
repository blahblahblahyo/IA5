//customer class

class Customer
{

        private String name;
        private int customerID;
        
        public Customer(){String name; int customerId= 0;}
        public Customer(String name){this.name=name;}
        public Customer(String name, int customerID){this.name=name; this.customerID=customerID;}
        
        public Customer(Customer c) {this(c.getName(), c.getID());} 



        public String getName()
        {
                return name;
        }

        public String setName(String newname)
        {
                this.name = newname;
                return name;
        }

        public int getID()
        {
                return customerID;
        }
        
        public int setId(int customerId)
        {
                return customerID;
        }

        public String toString()
        {
                System.out.println("customer: " + name + " customerId: " + customerID);
                String nicestring = (name +" " + customerID);
                return nicestring;
        } 

}
