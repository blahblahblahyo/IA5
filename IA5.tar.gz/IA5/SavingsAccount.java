

class SavingsAccount extends BankAccount{
    
    private double annualInterestRate= 0.05;
    private double minimumBalance;
    
    SavingsAccount(){}
    
    SavingsAccount(double air, double minbal){this.annualInterestRate = air; this.minimumBalance = minbal;}
    
    public void depositMonthlyInterest(){
        double mountlyInterest = annualInterestRate / 12.0;
        double newbal = getBalance();
        double updatebal = (newbal * mountlyInterest) + getBalance();
        setBalance(updatebal);
        
            
    }
    
    public double getAnnualInterestRate(){
        return annualInterestRate;
    }
    public void setAnnualInterestRate(double amounttoset){
        System.out.println(annualInterestRate);        
        if (amounttoset >= 0 && amounttoset <= 1){
            this.annualInterestRate = amounttoset;
        }
        else{ this.annualInterestRate = annualInterestRate;}
    }
    
    public double getMinimumBalance(){
        return minimumBalance;
    }
    
    public void setMinimumBalance(double newMin){
        
        this.minimumBalance = newMin;
        
    }
    public void withdraw(double amount){
        if((getBalance() - amount)>= minimumBalance){
            double nbalance =getBalance() - amount;
            setBalance(nbalance);
}
        }
    
    
    public static void main(String [] args){
        SavingsAccount gg = new SavingsAccount(.02, 2);
        gg.setAnnualInterestRate(1.1);
    }
}
