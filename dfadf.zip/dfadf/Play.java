

public class Play extends Theatre{

    private String writer;
    private int yearWritten= 2018;
    
    
    
    Play(String aTitle, int aRating, String aWriter, int ayearWritten)
    {super( aTitle, aRating); writer = aWriter; if(ayearWritten <= 2018)
    {yearWritten = ayearWritten;}}
    
    Play(Play toCopy)
    {
        super(toCopy); writer = toCopy.writer; yearWritten = toCopy.getYearWritten();}
        
    public int getYearWritten(){
        return yearWritten;
        }
        
    public void setYearWritten(int year){
        if(year <= 2018){
        yearWritten =  year;}
        }
        
    public String getWriter(){
        return writer;
        }
        
    public void setWriter(String write){
        writer = write;
        }
        
    public String getCategory(){
        if(yearWritten < 1819){
            return "Classic";
            }
            
        else if(yearWritten < 1969){
            return "Contemporary";
            }
            
        else
        {
            return "Modern";
            }
        
    }
    }
    
        
