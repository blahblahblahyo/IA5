import java.util.Date;


public class Movie extends Theatre{
    
    private String director;
    private Date releaseDate;
    
    
    
    Movie(String aTitle, int aRating, String aDirector, Date aReleaseDate){super(aTitle, aRating);
         director = aDirector; releaseDate = aReleaseDate;
        }
    
    Movie(Movie toCopy){super(toCopy);
         director = toCopy.director;
        
        
         //if((Date() + 31557600000l)> releaseDate)    
         
          releaseDate=toCopy.releaseDate;}
         
        
        public String getCategory(){
        String var;         
        if(8 < getRating()){
            var = "A";
            }
        else if(6 <getRating()){
            var = "B";
            }
            
        else if (4 < getRating()) { 
            var = "C"; 
           
        }
        
        else if (2 < getRating()) { 
            var = "D"; 
           
        }
        else{
            var = "F";
            }
        
                            
                      
        String vhar;         
        vhar = (releaseDate.toString() + "-" + var);
        return vhar;
        }            
                    
        
        
        public String getDirector(){
            return director;
            }
        
        public void setDirector(String aDirector){
            director = aDirector;
            }
            
        public Date getReleaseDate(){
            return releaseDate;
            }
            
        public void setReleaseDate(Date aReleaseDate){
            releaseDate = aReleaseDate;
            }
        }
        
        
