

public class Theatre{

    private String title = "HI";
    private int rating;
    
    public Theatre() { title = title; rating = rating; }
    
    Theatre(String aTitle, int aRating)
    {
    String nTitle = aTitle.toUpperCase();
    this.title = aTitle.toUpperCase(); 
    if (aRating < 11 && aRating >= 0) {  
        this.rating = aRating;
    }
    }
    Theatre(Theatre toCopy){title= toCopy.title.toUpperCase(); rating = toCopy.rating;}
    
    public String getTitle(){
        return title;
        }
        
    public String getCategory() {
        String var;
        if(8 < rating){
            var = "A";
            }
        else if(6 <rating) {
            var = "B";
            }
            
        else if (4 < rating) { 
            var = "C"; 
           
        }
        
        else if (2 < rating) { 
            var = "D"; 
           
        }
        else{
            var = "F";
            }
        return var;
        }
        
    public int getRating(){
        return rating;
        }
        
    public void setRating(int aRating){
        if(0<= aRating && aRating < 11){
            rating = aRating;
        }
        }
        
        
    public void setTitle(String atitle){
        
        
        title = atitle.toUpperCase();
        
        }
    }

